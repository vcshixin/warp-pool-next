/*
 * This is an OpenSSL-compatible implementation of the RSA Data Security, Inc.
 * MD5 Message-Digest Algorithm (RFC 1321).
 *
 * Homepage:
 * http://openwall.info/wiki/people/solar/software/public-domain-source-code/md5
 *
 * Author:
 * Alexander Peslyak, better known as Solar Designer <solar at openwall.com>
 *
 * This software was written by Alexander Peslyak in 2001.  No copyright is
 * claimed, and the software is hereby placed in the public domain.
 * In case this attempt to disclaim copyright and place the software in the
 * public domain is deemed null and void, then the software is
 * Copyright (c) 2001 Alexander Peslyak and it is hereby released to the
 * general public under the following terms:
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted.
 *
 * There's ABSOLUTELY NO WARRANTY, express or implied.
 *
 * See md5.c for more information.
 */

#ifndef _MD5_H
#define _MD5_H

#ifdef WITH_WOLFSSL
#include <wolfssl/options.h>
#endif

#if defined(WITH_WOLFSSL) && !defined(NO_MD5)
#include <wolfssl/openssl/md5.h>
#else

/* Any 32-bit or wider unsigned integer data type will do */
typedef unsigned int MD5_u32plus;

typedef struct {
	MD5_u32plus lo, hi;
	MD5_u32plus a, b, c, d;
	unsigned char buffer[64];
	MD5_u32plus block[16];
} MD5_CTX;

/* Remap public symbols to a 3proxy-private namespace so the bundled
   implementation does not collide with OpenSSL/libcrypto's MD5 symbols
   when statically linked. Callers keep using the MD5_* names. */
#define MD5_Init    _3proxy_MD5_Init
#define MD5_Update  _3proxy_MD5_Update
#define MD5_Final   _3proxy_MD5_Final

extern void MD5_Init(MD5_CTX *ctx);
extern void MD5_Update(MD5_CTX *ctx, const void *data, unsigned long size);
extern void MD5_Final(unsigned char *result, MD5_CTX *ctx);

#endif /* !WITH_WOLFSSL */

#endif
